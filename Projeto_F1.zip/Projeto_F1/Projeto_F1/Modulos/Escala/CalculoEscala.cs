﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_F1.Modulos.Escala
{
    class CalculoEscala
    {
        enum TipoTemperatura
        {
            CELSIUS,
            KELVIN,
            FAHRENHEIT
        }

        static public double Converter(TipoTemperatura EntradaTipo, double EntradaValor, TipoTemperatura SaidaTipo)
        {
            if (EntradaTipo == TipoTemperatura.CELSIUS && SaidaTipo == TipoTemperatura.KELVIN)
                return CelsiusParaKelvin(EntradaValor);
            else if (EntradaTipo == TipoTemperatura.CELSIUS && SaidaTipo == TipoTemperatura.FAHRENHEIT)
                return CelsiusParaFahrenheit(EntradaValor);
            else if (EntradaTipo == TipoTemperatura.KELVIN && SaidaTipo == TipoTemperatura.CELSIUS)
                return KelvinParaCelsius(EntradaValor);
            else if (EntradaTipo == TipoTemperatura.KELVIN && SaidaTipo == TipoTemperatura.FAHRENHEIT)
                return KelvinParaFahrenheit(EntradaValor);
            else if (EntradaTipo == TipoTemperatura.FAHRENHEIT && SaidaTipo == TipoTemperatura.CELSIUS)
                return FahrenheitParaCelsius(EntradaValor);
            else if (EntradaTipo == TipoTemperatura.FAHRENHEIT && SaidaTipo == TipoTemperatura.KELVIN)
                return FahrenheitParaKelvin(EntradaValor);
            else
                return 0;
        }

        static private double CelsiusParaKelvin(double Entrada)
        {
            return 0;
        }

        static private double CelsiusParaFahrenheit(double Entrada)
        {
            return 0;
        }

        static private double KelvinParaCelsius(double Entrada)
        {
            return 0;
        }

        static private double KelvinParaFahrenheit(double Entrada)
        {
            return 0;
        }

        static private double FahrenheitParaCelsius(double Entrada)
        {
            return 0;
        }

        static private double FahrenheitParaKelvin(double Entrada)
        {
            return 0;
        }
    }
}
